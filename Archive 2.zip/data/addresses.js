module.exports = ['Florida', 'Maine', 'New Mexico', 'California', 'Louisiana', 'Maryland', 'Mississippi', 'Indiana', 'Illinois', 'Nevada',
  'Michigan', 'Washington', 'Arizona', 'Michigan', 'Delaware', 'Missouri', 'Oklahoma', 'New Mexico', 'Vermont', 'Pennsylvania', 'Nebraska',
  'Ohio', 'Alabama', 'Mississippi', 'Virginia', 'Arkansas', 'Illinois', 'SouthCarolina', 'Delaware', 'Utah', 'Tennessee', 'Kentucky', 'Minnesota',
  'Texas', 'Vermont', 'SouthDakota', 'Montana', 'WestVirginia', 'Oregon', 'Indiana', 'Maryland', 'Oregon', 'NewMexico', 'Kentucky', 'Virginia', 'NewMexico',
  'NorthCarolina', 'New Hampshire', 'Montana', 'Texas', 'Indiana', 'SouthDakota', 'Kansas', 'NorthCarolina', 'SouthCarolina', 'Indiana', 'Idaho', 'NewHampshire',
  'Massachusetts', 'Alaska', 'Alaska', 'NewHampshire', 'Delaware', 'Montana', 'Oklahoma', 'Nevada', 'Hawaii', 'Utah', 'Tennessee', 'NewHampshire', 'Illinois', 'Tennessee',
  'Ohio', 'New Mexico', 'Ohio', 'Nevada', 'Michigan', 'Delaware', 'Oregon', 'Minnesota', 'Nebraska', 'NewHampshire', 'Mississippi', 'Virginia', 'Idaho', 'New Jersey',
  'Oregon', 'Michigan', 'Kentucky', 'California', 'Oregon', 'Texas', 'Wyoming', 'Hawaii', 'Kentucky', 'Iowa', 'Oklahoma', 'Florida', 'Delaware', 'Kansas'];


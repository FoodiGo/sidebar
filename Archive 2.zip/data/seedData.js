module.exports = [
  {
    id: 101,
    title: 'Mario\'s Magnificent Pasta',
    foodType: 'Italian',
    rating: 5,
    price: '$$$'
  },
  {
    id: 102,
    title: 'Garden Love',
    foodType: 'French',
    rating: 5,
    price: '$$$$'
  },
  {
    id: 103,
    title: 'Crow Cafe',
    foodType: 'Brunch',
    rating: 3,
    price: '$$$'
  },
  {
    id: 104,
    title: 'Bread n\' Butter',
    foodType: 'American',
    rating: 3,
    price: '$$'
  },
  {
    id: 105,
    title: 'Junction Jam',
    foodType: 'American',
    rating: 4,
    price: '$$$'
  },
  {
    id: 106,
    title: 'House of Tofu 99',
    foodType: 'Chinese',
    rating: 4,
    price: '$'
  },
  {
    id: 107,
    title: 'Blue\'s Cantina',
    foodType: 'Mexican',
    rating: 5,
    price: '$$$'
  },
  {
    id: 108,
    title: 'Lil\'s Restaurant',
    foodType: 'American',
    rating: 4,
    price: '$$$$'
  },
  {
    id: 109,
    title: 'Cantina Loca',
    foodType: 'Mexican',
    rating: 5,
    price: '$$'
  },
  {
    id: 110,
    title: 'My Fye Pizza',
    foodType: 'Pizza',
    rating: 4,
    price: '$'
  },
  {
    id: 111,
    title: 'Balaji',
    foodType: 'Indian',
    rating: 3,
    price: '$$'
  },
  {
    id: 112,
    title: 'Cafe Masala',
    foodType: 'Indian',
    rating: 5,
    price: '$$'
  },
  {
    id: 113,
    title: 'Loki Ramen',
    foodType: 'Chinese',
    rating: 4,
    price: '$'
  },
  {
    id: 114,
    title: 'Fortnite',
    foodType: 'American',
    rating: 5,
    price: '$$$'
  },
  {
    id: 115,
    title: 'Pub-G Bar and Grill',
    foodType: 'American',
    rating: 4,
    price: '$$$'
  },
  {
    id: 116,
    title: 'Louie Cheezy',
    foodType: 'French',
    rating: 4,
    price: '$$'
  },
  {
    id: 117,
    title: 'Bimini\'s',
    foodType: 'Brunch',
    rating: 5,
    price: '$$$'
  },
  {
    id: 118,
    title: 'French Jeson',
    foodType: 'French',
    rating: 4,
    price: '$$$$'
  },
  {
    id: 119,
    title: 'Wine & Crackers',
    foodType: 'American',
    rating: 5,
    price: '$$'
  },
  {
    id: 120,
    title: 'Luigi\'s',
    foodType: 'Italian',
    rating: 3,
    price: '$$'
  },
  {
    id: 121,
    title: 'Campo de Ambo',
    foodType: 'Pizza',
    rating: 4,
    price: '$$$'
  },
  {
    id: 122,
    title: 'Orange Blossom',
    foodType: 'Chinese',
    rating: 3,
    price: '$$'
  },
  {
    id: 123,
    title: 'Hong Kong',
    foodType: 'Chinese',
    rating: 5,
    price: '$$'
  },
  {
    id: 124,
    title: 'Costa America Mexican',
    foodType: 'Mexican',
    rating: 4,
    price: '$$$'
  },
  {
    id: 125,
    title: 'Blue Night',
    foodType: 'French',
    rating: 5,
    price: '$$$$'
  },
  {
    id: 126,
    title: 'Peg\'s Glorified Ham N Eggs',
    foodType: 'Brunch',
    rating: 5,
    price: '$$'
  },
  {
    id: 127,
    title: 'Great Full Gardens',
    foodType: 'American',
    rating: 5,
    price: '$$'
  },
  {
    id: 128,
    title: 'Laughing Planet Cafe',
    foodType: 'Brunch',
    rating: 3,
    price: '$$$'
  },
  {
    id: 129,
    title: 'Little Waldrof Saloon',
    foodType: 'Pizza',
    rating: 3,
    price: '$$'
  },
  {
    id: 130,
    title: 'Tamarack Junction',
    foodType: 'American',
    rating: 3,
    price: '$$$'
  },
  {
    id: 131,
    title: 'Tofu House',
    foodType: 'Chinese',
    rating: 4,
    price: '$$'
  },
  {
    id: 132,
    title: 'Red\'s Broken Bat',
    foodType: 'Mexican',
    rating: 5,
    price: '$$'
  },
  {
    id: 133,
    title: 'Lulou\'s Restaurant',
    foodType: 'American',
    rating: 4,
    price: '$$$$'
  },
  {
    id: 134,
    title: 'Restaurante Yesenia',
    foodType: 'Mexican',
    rating: 5,
    price: '$'
  },
  {
    id: 135,
    title: 'My Pie Pizza',
    foodType: 'Pizza',
    rating: 4,
    price: '$'
  },
  {
    id: 136,
    title: 'Flavors of India',
    foodType: 'Indian',
    rating: 3,
    price: '$$'
  },
  {
    id: 137,
    title: 'Cafe Masala',
    foodType: 'Indian',
    rating: 5,
    price: '$$'
  },
  {
    id: 138,
    title: 'The Wok Chinese Cuisine',
    foodType: 'Chinese',
    rating: 4,
    price: '$$'
  },
  {
    id: 139,
    title: 'Fortune',
    foodType: 'Chinese',
    rating: 2,
    price: '$$$'
  },
  {
    id: 140,
    title: 'Beaujolais Bistro',
    foodType: 'French',
    rating: 4,
    price: '$$$'
  },
  {
    id: 141,
    title: 'Chez Louie',
    foodType: 'French',
    rating: 4,
    price: '$$'
  },
  {
    id: 142,
    title: 'Mimi\'s Cafe',
    foodType: 'Brunch',
    rating: 3,
    price: '$$'
  },
  {
    id: 143,
    title: 'French Quarters',
    foodType: 'French',
    rating: 1,
    price: '$$$$'
  },
  {
    id: 144,
    title: 'Rick’s Pizza Beer & More',
    foodType: 'Pizza',
    rating: 5,
    price: '$$'
  },
  {
    id: 145,
    title: 'Tommaato\'s',
    foodType: 'Italian',
    rating: 3,
    price: '$$'
  },
  {
    id: 146,
    title: 'Campo',
    foodType: 'Pizza',
    rating: 4,
    price: '$$$'
  },
  {
    id: 147,
    title: 'Chinese Duck House',
    foodType: 'Chinese',
    rating: 3,
    price: '$'
  },
  {
    id: 148,
    title: 'Jazmine',
    foodType: 'Chinese',
    rating: 5,
    price: '$$'
  },
  {
    id: 149,
    title: 'Costa Vida Fresh Mexican Grill',
    foodType: 'Mexican',
    rating: 3,
    price: '$'
  },
  {
    id: 150,
    title: 'Midtown Eats',
    foodType: 'American',
    rating: 4,
    price: '$$$'
  },
  {
    id: 151,
    title: "Cucina Urbana",
    foodType: "Italian",
    rating: '5',
    price: '$$',
  },
  {
    id: 152,
    title: "Phil's BBQ",
    foodType: "American",
    rating: 4,
    price: '$$',
  },
  {
    id: 153,
    title: "Lucha Libre Gourmet Taco Shop",
    foodType: "Mexican",
    rating: 4,
    price: "$",
  },
  {
    id: 154,
    title: "Barbusa",
    foodType: "Italian",
    rating: 5,
    price: "$$",
  },
  {
    id: 155,
    title: "JV's Taco Shop",
    foodType: "Mexican",
    rating: 5,
    price: "$",
  },
  {
    id: 156,
    title: "Maritza's",
    foodType: "Mexican",
    rating: 5,
    price: "$",
  },
  {
    id: 157,
    title: "Robertos",
    foodType: "Mexican",
    rating: 4,
    price: "$",
  },
  {
    id: 158,
    title: "C Level",
    foodType: "American",
    rating: 5,
    price: "$$",
  },
  {
    id: 159,
    title: "Tacos El Paisa",
    foodType: "Mexican",
    rating: 5,
    price: "$",
  },
  {
    id: 160,
    title: "Il Postino",
    foodType: "Italian",
    rating: 4,
    price: "$$",
  },
  {
    id: 161,
    title: "Vallarta Express Mexican Eatery",
    foodType: "Mexican",
    rating: 5,
    price: "$$$",
  },
  {
    id: 162,
    title: "Cafe Coyote",
    foodType: "Mexican",
    rating: 3,
    price: "$$",
  },
  {
    id: 163,
    title: "Super Cocina",
    foodType: "Italian",
    rating: 5,
    price: "$",
  },
  {
    id: 164,
    title: "El Comal",
    foodType: "Mexican",
    rating: 4,
    price: "$$",
  },
  {
    id: 165,
    title: "Ballast Point",
    foodType: "American",
    rating: 4,
    price: "$$",
  },
  {
    id: 166,
    title: "Cotixan",
    foodType: "Mexican",
    rating: 4,
    price: "$$",
  },
  {
    id: 167,
    title: "Buona Forchetta",
    foodType: "Italian",
    rating: 5,
    price: "$$",
  },
  {
    id: 168,
    title: "Filippi's Pizza Grotto",
    foodType: "Pizza",
    rating: 4,
    price: "$$",
  },
  {
    id: 169,
    title: "Point Loma Seafood's",
    foodType: "American",
    rating: 4,
    price: "$$",
  },
  {
    id: 170,
    title: "The Fishery",
    foodType: "American",
    rating: 4,
    price: "$$",
  },
  {
    id: 171,
    title: "The Broken Yolk",
    foodType: "Brunch",
    rating: 5,
    price: "$$",
  },
  {
    id: 172,
    title: "Water Grill",
    foodType: "American",
    rating: 4,
    price: "$$$",
  },
  {
    id: 173,
    title: "Hash House A Go Go",
    foodType: "Brunch",
    rating: 4,
    price: "$$",
  },
  {
    id: 174,
    title: "Pardon My French Bar & Kitchen",
    foodType: "Brunch",
    rating: 5,
    price: "$$",
  },
  {
    id: 175,
    title: "Maggie's Cafe",
    foodType: "Brunch",
    rating: 5,
    price: "$$",
  },
  {
    id: 176,
    title: 'North Beach Pizza',
    foodType: 'Pizza',
    rating: 2,
    price: '$$',
  },
  {
    id: 177,
    title: 'Agrodolce Osteria',
    foodType: 'Italian',
    rating: 5,
    price: '$$$',
  },
  {
    id: 178,
    title: 'Zut!',
    foodType: 'American',
    rating: 4,
    price: '$$$',
  },
  {
    id: 179,
    title: 'Chez Panisse',
    foodType: 'French',
    rating: 5,
    price: '$$$$',
  },
  {
    id: 180,
    title: 'French Laundry',
    foodType: 'French',
    rating: 5,
    price: '$$$$',
  },
  {
    id: 181,
    title: 'Shandong',
    foodType: 'Chinese',
    rating: 3,
    price: '$',
  },
  {
    id: 182,
    title: 'Cafe M',
    foodType: 'Brunch',
    rating: 3,
    price: '$$',
  },
  {
    id: 183,
    title: 'Burma Superstar',
    foodType: 'Indian',
    rating: 3,
    price: '$$',
  },
  {
    id: 184,
    title: '900 Grayson',
    foodType: 'Brunch',
    rating: 4,
    price: '$$$',
  },
  {
    id: 185,
    title:'Longbranch Saloon',
    foodType: 'American',
    rating: 4,
    price: '$$',
  },
  {
    id: 186,
    title: 'Paisan',
    foodType: 'Pizza',
    rating: 4,
    price: '$$',
  },
  {
    id: 187,
    title: 'Townhouse Bar & Grill',
    foodType: 'American',
    rating: 2,
    price: '$$$',
  },
  {
    id: 188,
    title: 'Doña Tomas',
    foodType: 'Mexican',
    rating: 4,
    price: '$$',
  },
  {
    id: 189,
    title: 'Cheese Board Pizza',
    foodType: 'Pizza',
    rating: 3,
    price: '$$',
  },
  {
    id: 190,
    title: 'Funky Elephant',
    foodType: 'Indian',
    rating: 2,
    price: '$',
  },
  {
    id: 191,
    title: 'La Marcha',
    foodType: 'Mexican',
    rating: 1,
    price: '$$',
  },
  {
    id: 192,
    title: 'Jupiter',
    foodType: 'Pizza',
    rating: 4,
    price: '$',
  },
  {
    id: 193,
    title: 'Grégoire',
    foodType: 'French',
    rating: 3,
    price: '$$$',
  },
  {
    id: 194,
    title: 'Trattoria La Siciliana',
    foodType: 'Italian',
    rating: 4,
    price: '$$',
  },
  {
    id: 195,
    title: 'Amy\'s Baking Company',
    foodType: 'American',
    rating: 1,
    price: '$$$',
  },
  {
    id: 196,
    title: 'Berkeley Social Club',
    foodType: 'American',
    rating: 3,
    price: '$$',
  },
  {
    id: 197,
    title: 'Saha',
    foodType: 'Indian',
    rating: 4,
    price: '$$',
  },
  {
    id: 198,
    title: 'Corso',
    foodType: 'Italian',
    rating: 4,
    price: '$$',
  },
  {
    id: 199,
    title: 'Guacamole 61',
    foodType: 'Mexican',
    rating: 3,
    price: '$',
  },
  {
    id: 200,
    title: 'Los Moles',
    foodType: 'Mexican',
    rating: 2,
    price: '$$',
  },
];
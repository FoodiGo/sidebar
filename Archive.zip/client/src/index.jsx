import Sidebar from './app.jsx';
import 'bootstrap/dist/css/bootstrap.css';

window.Sidebar = Sidebar;
